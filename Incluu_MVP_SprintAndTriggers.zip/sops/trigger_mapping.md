# Trigger Mapping

- VIP → Podia Fulfillment Only
- Corporate → Podia + CRM + 1 Agent
- Enterprise → All Automations
- Government → All + Audit Layer
