# Agent Delivery Instructions

Each license tier maps to specific Make automation bundles. Deliverables are linked via activation key.