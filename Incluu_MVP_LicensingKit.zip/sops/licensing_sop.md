# Licensing SOP

1. Issue license key from Airtable
2. Trigger Make scenario
3. Confirm delivery via Slack/email
4. Log provisioning