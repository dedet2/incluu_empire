# License Terms & Compliance

1. Scope of Use
2. Limitations
3. Data Governance
4. Termination
