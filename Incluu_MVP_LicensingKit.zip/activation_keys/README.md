# License Key Activation

Match the license key in Airtable and use it to unlock the Make scenario delivery.