# Weekly Reflection

- What did I learn?
- What worked well?
- What needs improvement?