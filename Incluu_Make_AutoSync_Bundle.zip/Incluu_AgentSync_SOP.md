# Incluu Empire Agent Sync System

## Components
1. Google Apps Script: auto-sync files from GitHub to Drive
2. Make.com: monitors GitHub and triggers Apps Script
3. Slack: notifies team on success/fail
4. Airtable: tracks last sync + status

## Setup Steps
1. Deploy the Apps Script
2. Import Make Scenario
3. Add Slack Webhook URL to Script Properties
4. Add PAT_GITHUB token
5. Test using sample zip file commit