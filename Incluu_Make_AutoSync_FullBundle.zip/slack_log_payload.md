{
  "text": "📂 File synced to Drive: *{{filename}}*
Status: `{{status}}`
Time: {{timestamp}}"
}