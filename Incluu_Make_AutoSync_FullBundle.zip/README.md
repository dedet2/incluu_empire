# Incluu GitHub → Google Drive AutoSync Bundle

## What's Inside
- `drive_upload.gs`: Google Apps Script for syncing any file from GitHub to Google Drive.
- `make_scenario.json`: Make.com scenario to automate the sync trigger.
- `airtable_log_fields.csv`: For Airtable logging (filename, status, timestamp).
- `slack_log_payload.md`: Optional Slack payload format for alerts.

## Setup Steps
1. Copy `drive_upload.gs` into Google Apps Script.
2. Replace `YOUR_GITHUB_PAT` with your GitHub personal access token.
3. Run `syncAllGithubFilesToDrive()` or schedule it via Make.com.