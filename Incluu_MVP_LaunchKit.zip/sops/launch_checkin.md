# Weekly Reflection

- What went well?
- What to improve?
- Automation review