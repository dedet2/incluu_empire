# Incluu Gmail Fallback Rebuild

This folder contains the prebuilt scenario for Make.com used as a fallback when Podia webhook delivery fails.

- Includes Gmail email watcher
- Parses Podia user/order details
- Logs to Airtable
- Notifies via Slack
