# Incluu Gmail Fallback Setup

This module listens to fallback emails from Podia when webhook fails.

## Modules Pre-Built:
- Gmail: Watch Emails (filtered from `@epodia.com`)
- Text Parser
- Airtable: Create Record in `Incluu_GmailFallback_Airtable`
- Slack: Send Message to your Slack channel
- (Optional) Kit module to connect to your AI agent

## Setup Instructions:
1. Import the JSON into a **new blank scenario** in Make.com.
2. Authenticate Gmail, Airtable, Slack.
3. Run once in test mode.
4. Toggle to Active.

